# Learning Here
from a youtube tutorial!!!!
i hope i will stick till last untill i crack it dowm
